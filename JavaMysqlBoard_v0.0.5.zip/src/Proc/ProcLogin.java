package Proc;

import DB.DB;
import Util.Csc;
import Util.Ctx;

public class ProcLogin {
	
	static void run() { // 아이디 어딘가에 저장해야... 
		
		String id="";
		String pw="";
		
		while(true) {
			
			Ctx.wn("아이디를 입력하세요.");
			id = Csc.readlong();
			
			Ctx.wn("비밀번호를 입력하세요.");
			pw = Csc.readlong();
			
			if(DB.dblogin(id, pw)) {
				Ctx.wn("로그인 성공");	
				break;
			}
			else {
				Ctx.wn("로그인 실패");
			}
		}
		
	}
}
