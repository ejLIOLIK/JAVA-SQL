package Admin;

import DB.DB;
import Mysql.Display;
import Util.Csc;
import Util.Ctx;

public class ProcReport {
	
	static final int ADMINPAGE = 5;
	static final int REPORTNUM = 2;
	
	
	static void run() {
		
		String str = "select * from board where report > REPORTNUM ";
		int mount = DB.countBoard("select count(*) from board where report > REPORTNUM ");
		int key = 1; // 첫 페이지
		int mountPage;		
		String num = "";
				
		if(mount%ADMINPAGE==0) {
			mountPage = mount/ADMINPAGE;
		}
		else {
			mountPage = mount/ADMINPAGE+1;
		}
		
		Display.showListTitleAdmin();
		DB.dbExecuteQueryListAdmin(str + "order by num desc limit 0,5"); //신고글 출력
		Display.Line();
		Display.space(53);
		Ctx.wn("page" + key + "/" + mountPage);

		roop_rpt : while (true) {
			Display.Line();
			Ctx.wn("[1~" + mountPage + "] 해당 페이지로 이동 [e] 뒤로 [d] 삭제 [r] 복구 ");
			String keyStr = Csc.readlong();
			
			switch(keyStr) {
			case "e" :
			break roop_rpt;
			case "d" :
				Ctx.wn("삭제할 게시글 번호를 입력하세요.");
				num = Csc.readlong();
				DB.dbExecuteUpdate("delete from board where num=" + num); // 
				Ctx.wn(num + "번 게시글 삭제.");
				break;
			case "r" :
				Ctx.wn("복구할 게시글 번호를 입력하세요.");
				num = Csc.readlong();
				DB.dbExecuteUpdate("update board set report = 0 where num=" + num); // 
				Ctx.wn(num + "번 게시글 복구.");
				break;
				default:
					key = Util.Cet.intToString(keyStr);
					
					if (key > mountPage || key < 1) {
						Ctx.wn("해당 페이지가 없습니다.");
					} else {
						Display.showListTitleAdmin();
						DB.dbExecuteQueryListAdmin(str + "order by num desc limit " + ((key - 1) * ADMINPAGE) + "," + ADMINPAGE + ";"); //신고글 출력
						Display.Line();
						Display.space(53);
						Ctx.wn("page" + key + "/" + mountPage);
					}
			}
		}
	}
}

