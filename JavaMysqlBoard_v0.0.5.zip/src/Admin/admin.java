package Admin;

import Util.Csc;
import Util.Ctx;

public class admin {
	
	public static void run() {

		String cmd = "";

		loop_adminQuit: while (true) {
			Ctx.wn(" [1]신고 게시글 조회 [e]나가기 ");
			cmd = Csc.readlong();
			switch (cmd) {
			case "1":
				ProcReport.run();
				break;
			case "e":
				break loop_adminQuit;
			default:
			}
		}
	}
}