package Mysql;

import Proc.ProcLogin;
import Util.Ctx;

public class Display {
	
	final static int DPNUM = 70;
	
	static private String TITLE = "게시판 v0.0.4"; 
	
	static public void showTitle() {
		dotT();
		space(30);
		System.out.println(TITLE);
		dotT();
	}
	
	static private String MAIN_MENU = "[1]리스트 [2]글읽기 [3]글쓰기 [4]글삭제 [5]글수정 [6]검색 [e]종료";
	static private String LOGIN_MENU = "[7]로그인 [8]회원가입";
	static private String LOGOUT_MENU = "[7]로그아웃";
	static private String REPLY_MENU = "[1]리플입력 [2]추천 [3]신고 [e]뒤로";
	
	public static void Line() {
		for(int i=0;i<DPNUM;i++) {
			Ctx.w("-");
		}
		Ctx.wn("");
	}
	
	public static void dotT() {
		for(int i=0;i<DPNUM;i++) {
			Ctx.w("=");
		}
		Ctx.wn("");
	}
	
	public static void space(int c) {
		for(int i=0;i<c;i++) {
			Ctx.w(" ");
		}
	}
	
	static public void showMainMenu() {
		
		dpLoginId();
		Line();
		space(8);
		Ctx.wn(MAIN_MENU);
		
		if(ProcLogin.blLogin) {
			space(51);
			Ctx.wn(LOGOUT_MENU);
		}
		else {
			space(46);
			Ctx.wn(LOGIN_MENU);
		}
		Line();	
	}
	
	static public void showReplyMenu() {
		Line();
		space(14);
		Ctx.wn(REPLY_MENU);
		Line();	
	}
	
	static public void showListTitle () { 
		dpLoginId();
		Display.Line();
		Ctx.wn(Ctx.padR("글번호", 7) + Ctx.padR("ID", 12) + Ctx.padR("제목", 29) + Ctx.padR("조회수", 7) + Ctx.padR("추천수", 7));
		Display.Line();
	}
	
	static public void showListTitleAdmin () { 
		Display.Line();
		Ctx.wn(Ctx.padR("글번호", 7) + Ctx.padR("ID", 12) + Ctx.padR("제목", 29) + Ctx.padR("조회수", 7) + Ctx.padR("추천수", 7) + Ctx.padR("신고수", 7));
		Display.Line();
	}
	
	static public void showReplyTitle () {
		Ctx.wn(Ctx.padR(" ID", 12) + Ctx.padR("내용", 33) + "작성시간");
	}
	
	static public void dpLoginId() {
		
		Ctx.w(" ID: ");
		
		if(ProcLogin.blLogin) {
			Ctx.wn(ProcLogin.idLogin);
		}
		else {
			Ctx.wn("손님");
		}
	}
	
}
