package Mysql;

import Proc.ProcBoard;

public class Main {
	public static void main(String[] args) {
		ProcBoard procBoard=new ProcBoard();
		procBoard.run();
	}
}