package Util;

public class Ctx {
	
	public static void w(String s) {
		System.out.print(s);
	}
	public static void wn(String s) {
		System.out.println(s);
	}
	
    public static String padL(String s, int n) {
        return String.format("%" + n + "s", s);
    }
 
    public static String padR(String s, int n) {
        return String.format("%-" + n + "s", s);
    }
}
