package Proc;

import DB.DB;
import Mysql.Display;
import Util.Csc;
import Util.Ctx;

public class ProcListsql {
	
	final static int PAGE = 5;
	
	static void run() {
		
		String str = "select * from board where report<3 ";
		int mount = DB.countBoard("select count(*) from board where report<3 ");
		
		int key;
		int mountPage;
				
		if(mount%PAGE==0) {
			mountPage = mount/PAGE;
		}
		else {
			mountPage = mount/PAGE+1;
		}
		
		printListPage(str + "order by num desc limit 0,5;", 1, mountPage);

		roop_listQuit : while (true) {
			Display.Line();
			Ctx.wn("[1~" + mountPage + "] 해당 페이지로 이동 [e] 뒤로 ");
			String keyStr = Csc.readlong();
						
			switch(keyStr) {
			case "e" :
			break roop_listQuit;
				default:
					key = Util.Cet.intToString(keyStr);
					
					if (key > mountPage || key < 1) {
						Ctx.wn("해당 페이지가 없습니다.");
					} else {
						printListPage(str + "order by num desc limit " + ((key - 1) * PAGE) + "," + PAGE + ";"
								, key, mountPage);
					}
			}
			
		}
	} 
	
	static void printListPage(String query, int key, int mountPage) {
		
		Display.showListTitle();
		DB.dbExecuteQueryList("select * from board where report<3 order by recmd desc limit 0,3"); // 추천글 페이지 출력
		Display.Line();
		DB.dbExecuteQueryList(query); // 페이지 출력
		Display.Line();
		Display.space(30);
		Ctx.wn("page" + (key) + "/" + mountPage);
	}

}
