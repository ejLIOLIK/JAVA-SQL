package Proc;

import DB.DB;
import Util.Csc;
import Util.Ctx;

public class ProcRegister {

	static void run() {
		
		String cmd="";
		
		String email="";
		String id="";
		String pw="";
		
		Ctx.wn("이메일을 입력하세요.");
		cmd = Csc.readlong();
		email = cmd;
		
		while(true) {
			Ctx.wn("아이디를 입력하세요.");
			cmd = Csc.readlong();
			id = cmd;
			
			if(id.equals("손님") || id.equals("e"))
			{
				Ctx.wn("사용할 수 없는 아이디입니다.");
				
			}
			else if(DB.dbIdcheck(id))
			{
				Ctx.wn("이미 존재하는 아이디입니다.");
			}
			else {
				break;
			}
		}
		
		while(true) {
			Ctx.wn("비밀번호를 입력하세요.");
			cmd = Csc.readlong();
			pw = cmd;

			Ctx.wn("비밀번호를 다시 입력하세요.");
			cmd = Csc.readlong();

			if (pw.equals(cmd)) {
				Ctx.wn("등록되었습니다.");
				break;
			} else {
				Ctx.wn("일치하지 않습니다.");
			}
		}
		
		DB.dbExecuteUpdate("insert into register (email, id, pw) values ('"+ email +"', '"+ id +"', '"+ pw +"')");
		Ctx.wn("등록이 완료되었습니다. 로그인 창으로 이동합니다.");
		
		 ProcLogin.run();

	}
}
