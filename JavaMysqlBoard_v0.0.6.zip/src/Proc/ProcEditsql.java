package Proc;

import Admin.admin;
import DB.DB;
import Util.Csc;
import Util.Ctx;

public class ProcEditsql {
	
	static void run() {
		
		String tmp="";

		Ctx.wn("수정할 글 번호를 입력하세요. [e]뒤로");
		String num = Csc.readlong();
		
		if (!num.equals("e")) {

			if(DB.dbIdcheckEditDel(num) || admin.lbAdminId()) {

			Ctx.wn("수정할 부분을 선택하세요.");
			Ctx.wn("[1]글제목 [2]글내용");
			String editStr = Csc.readlong();

			Ctx.wn("수정할 내용을 입력하세요.");
			tmp = Csc.readlong();

			switch (editStr) {
			case "1":
				DB.dbExecuteUpdate("update board set title='" + tmp + "' where num=" + num);
				break;
			case "2":
				DB.dbExecuteUpdate("update board set contents='" + tmp + "' where num=" + num);
				break;
//		case "3": // 로그인 기능 도입으로 ID 수정기능 삭제
//			DB.dbExecuteUpdate("update board set ID='" + tmp + "' where num=" + num); 
//			break;
			default:
			}

			Ctx.wn(num + "번 게시글이 수정되었습니다.");
			}
			else{
				Ctx.wn("수정 권한이 없습니다.");
			}
		}
	}

}
