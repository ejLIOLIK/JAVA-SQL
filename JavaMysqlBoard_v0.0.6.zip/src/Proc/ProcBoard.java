package Proc;

import Admin.admin;
import DB.DB;
import Mysql.Display;
import Util.Csc;
import Util.Ctx;

public class ProcBoard {

	public void run() {
		
		Display.showTitle();
		DB.dbInit();
		
		loop_quit : while(true) {
		
			String key = "";
			
			Display.showMainMenu();
			key = Csc.readlong();

			// [1]글리스트 [2]글읽기 [3]글쓰기 [4]글삭제 [5]글수정 [6]검색 [e]종료
			// [7]로그인 [8]회원가입 [9]로그아웃
			switch (key) {
			case "1":
				ProcListsql.run();
				break;
			case "2":
				ProcReadsql.run();
				break;
			case "3":
				if(ProcLogin.blLogin) {
					ProcWritesql.run();}
				else {
					Ctx.wn("로그인 후 이용해주세요.");}
				break;
			case "4":
				if(ProcLogin.blLogin) {
					ProcDeletesql.run();}
				else {
					Ctx.wn("로그인 후 이용해주세요.");}
				break;
			case "5":
				if(ProcLogin.blLogin) {
					ProcEditsql.run();}
				else {
					Ctx.wn("로그인 후 이용해주세요.");}
				break;
			case "6":
				ProcSearchsql.run();
				break;
			case "7":
				 ProcLogin.run();
				break;
			case "8":
				ProcRegister.run();
				break;
			case "e":
				Ctx.wn("종료됩니다.");
				break loop_quit;
			case "admin":
				if(ProcLogin.blLogin && ProcLogin.idLogin.equals("admin")){
					admin.run(); // 관리자모드
				}
				break;
			default:
			}
		
		}
	}
}
