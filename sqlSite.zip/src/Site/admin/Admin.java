package Site.admin;

public class Admin {
	public static void run() {
		
	}
}
