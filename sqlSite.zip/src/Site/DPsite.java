package Site;

import Site.Proc.ProcLogin;
import Util.Cdp;
import Util.Ctx;

public class DPsite {
	
	final static int DPNUM = 65;
	final static String SITETITLE = "사이트 v0.0.5";

	public static void dpSiteTitle() {
		
		String dot = "#";
		
		Cdp.line(dot, DPNUM);
		Ctx.w(dot);
		Cdp.space(26);
		Ctx.w(SITETITLE);
		Cdp.space(26);
		Ctx.wn(dot);
		Cdp.line(dot, DPNUM);
		
	}
	
	public static void dpSiteMenu() {
		
		String dot = "=";
		
		//[b]자유게시판 [m]장터게시판 [o]로그아웃
		
		if(ProcLogin.blLogin){
			Ctx.wn("ID : " + ProcLogin.idLogin);
		}
		else {
			Ctx.wn("현재 손님입니다. 로그인 해주세요");
		}
		
		Cdp.line(dot, DPNUM);
		
		if(ProcLogin.blLogin) {
			Cdp.space(28);
			Ctx.wn("[b]자유게시판 [m]장터게시판 [o]로그아웃 [q]종료");
		}
		else {
			Cdp.space(41);
			Ctx.wn("[o]로그인 [p]회원가입 [q]종료");
		}
		
		Cdp.line(dot, DPNUM);
		
	}
	
}
