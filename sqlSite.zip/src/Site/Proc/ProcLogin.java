package Site.Proc;

import Site.Board.DB.DB;
import Util.Csc;
import Util.Ctx;

public class ProcLogin {
	
	public static boolean blLogin = false;
	public static String idLogin = "";
	
	public static void run() {
		
		String cmd = "";
		String id = "";
		String pw = "";
		
		while(true) {
		
			Ctx.wn("아이디를 입력하세요. [q]뒤로");
			cmd = Csc.readlong();
			id = cmd;

			if (cmd.equals("q")) {
				break;
			}

			Ctx.wn("비밀번호를 입력하세요.");
			cmd = Csc.readlong();
			pw = cmd;
			
			if(DB.dbLogin(id, pw)) {
				blLogin = true;
				idLogin = id;
				
				Ctx.wn("로그인 성공.");
				break;
			}
			else {
				Ctx.wn("로그인 실패. 다시 입력하세요.");
			}		
		}
	}

	public static void logout() {
		blLogin = false;
		idLogin = "";
		
		Ctx.wn("로그아웃 성공.");
	}
}
