package Site;

import Site.Board.DB.DB;
import Site.Board.Proc.ProcBoard;
import Site.Proc.ProcLogin;
import Site.Proc.ProcRegist;
import Util.Csc;
import Util.Ctx;

public class Site {

	public void run() {

		String cmd = "";

		DB.dbInit();
		ProcBoard procBoard = new ProcBoard();

		DPsite.dpSiteTitle();

		loop_site: while (true) {

			DPsite.dpSiteMenu();

			// [b]자유게시판 [m]장터게시판 [o]로그아웃 [종료]

			cmd = Csc.readlong();

			switch (cmd) {
			case "b":
				procBoard.run("board", "reply");
				break;
			case "m":
				procBoard.run("board_market", "reply_market");
				break;
			case "o":
				if (ProcLogin.blLogin) {
					ProcLogin.logout();
				} else {
					ProcLogin.run();
				}
				break;
			case "p":
				if (!ProcLogin.blLogin) {
					ProcRegist.run();
				}
				break;
			case "q":
				Ctx.wn("종료합니다.");
				break loop_site;
			case "admin":
				if(ProcLogin.idLogin.equals("admin"))
				{
					// 관리자모드
				}
				break;
			default:

			}
		}

	}

}
