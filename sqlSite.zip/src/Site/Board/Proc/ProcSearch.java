package Site.Board.Proc;

import Site.Board.DB.DB;
import Util.Cdp;
import Util.Cet;
import Util.Csc;
import Util.Ctx;

public class ProcSearch {

	final static int PAGENUM = 7;
	static int mountPage = 0; // 총 페이지 수
	static int curPage = 1; // 현재 페이지. 시작값 1.

	static void run() {

		String cmd = "";
		String search = "";
		String query = "";
		String countQ = "";

		int mountPost;

		Ctx.wn("검색어를 입력하세요. [q]뒤");
		cmd = Csc.readlong();
		search = cmd;

		countQ = "select count(*) from " + DB.TABLE + " where report<3 and title like '%" + search + "%'";

		mountPost = DB.dbCountQuery(countQ); // 총 게시글 수
		if (mountPost % PAGENUM == 0) {
			mountPage = mountPost / PAGENUM;
		} else {
			mountPage = mountPost / PAGENUM + 1;
		}

		while (true) {

			query = "select * from " + DB.TABLE + " where report<3 and title like '%" + search + "%'"
			+" order by num desc limit " + (curPage - 1)*PAGENUM + "," + PAGENUM + " ";

			dpSearchTitle();
			DB.dbExecuteQueryList(query);

			if (mountPost == 0) {
				Ctx.wn("검색 결과가 없습니다.");
				mountPage = 1;
			}

			dpSearchFin();

			Ctx.wn("이동하고자 하는 페이지 번호를 입력하세요. [r]읽기 [q]뒤로");
			cmd = Csc.readlong();

			if (cmd.equals("q")) {
				break;
			} else if (cmd.equals("r")) {
				ProcRead.run(); // 읽기 후 다시 검색 리스트로 돌아가게 
				curPage = 1; // 첫 페이지로
			} else {
				curPage = Cet.intToString(cmd);

				if (curPage > mountPage || curPage < 1) {
					Ctx.wn("존재하지 않는 페이지입니다.");
					break;
				}
			}
		}
	}

	static void dpSearchTitle() {
		Ctx.wn(Ctx.padR("번호", 5) + Ctx.padR("제목", 30) + Ctx.padR("작성자", 10) + Ctx.padR("조회수", 5) + Ctx.padR("추천수", 5)
				+ "날짜");
		Cdp.line("-", DP.DPNUM);
	}

	static void dpSearchFin() {
		Cdp.line("-", DP.DPNUM);
		Cdp.space(38);
		Ctx.wn("현재 페이지 [" + curPage + "/" + mountPage + "]");
		Cdp.line("-", DP.DPNUM);
	}

}
