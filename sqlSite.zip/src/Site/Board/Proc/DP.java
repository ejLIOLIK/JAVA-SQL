package Site.Board.Proc;

import Site.Board.DB.DB;
import Site.Proc.ProcLogin;
import Util.Cdp;
import Util.Ctx;

public class DP {
	
	final static int DPNUM = 65;
	
	public static void dpBoardTitle() {
		
		String dot = "#";
		
		Cdp.line(dot, DPNUM);
		Ctx.w(dot);
		
		if (DB.TABLE.equals("board")){
			Cdp.space(28); Ctx.w("자유게시판");
		}
		else if (DB.TABLE.equals("board_market")){
			Cdp.space(28); Ctx.w("마켓게시판");
		}
		
		Cdp.space(28);
		Ctx.wn(dot);
		Cdp.line(dot, DPNUM);
		
	}
	
	public static void dpBoardMenu() {
	
		String dot = "=";
		
		//메인화면이 게시판 리스트
		//[l]리스트 [r]읽기 [s]검색 [w]쓰기 [e]수정 [d]삭제 [q]종료
		//[o]로그인 [p]회원가입
		
		if(ProcLogin.blLogin){
			Ctx.wn("ID : " + ProcLogin.idLogin);
		}
		else {
			Ctx.wn("현재 손님입니다. 로그인 해주세요");
		}
		
		Cdp.line(dot, DPNUM);
		Cdp.space(11);
		Ctx.wn("[l]리스트 [r]읽기 [s]검색 [w]쓰기 [e]수정 [d]삭제 [q]뒤로");
		
//		if(ProcLogin.blLogin) {
//			Cdp.space(48);
//			Ctx.wn("[o]로그아웃");
//		}
//		else {
//			Cdp.space(40);
//			Ctx.wn("[o]로그인 [p]회원가입");
//		}
		
		Cdp.line(dot, DPNUM);
		
	}
	
}
