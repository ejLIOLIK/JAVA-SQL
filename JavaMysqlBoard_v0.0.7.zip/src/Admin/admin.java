package Admin;

import Mysql.Display;
import Proc.ProcLogin;
import Util.Csc;
import Util.Ctx;

public class admin {
	
	public static void run() {

		String cmd = "";

		loop_adminQuit: while (true) {
			Display.Line();
			Ctx.wn(" [1]신고 게시글 관리 [2]회원 정보 관리 [e]나가기 ");
			Display.Line();
			cmd = Csc.readlong();
			switch (cmd) {
			case "1":
				ProcReport.run();
				break;
				case "2":
				ProcMeminfo.run();
				break;
			case "e":
				break loop_adminQuit;
			default:
			}
		}
	}
	
	public static boolean lbAdminId() {
		if(ProcLogin.blLogin && ProcLogin.idLogin.equals("admin")) {
			return true;
		}
		else{
			return false;
		}
	}
}