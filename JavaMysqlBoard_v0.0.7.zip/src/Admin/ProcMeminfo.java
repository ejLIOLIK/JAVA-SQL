package Admin;

import DB.DB;
import DB.DBmem;
import Mysql.Display;
import Util.Csc;
import Util.Ctx;

public class ProcMeminfo {

	final static int MEMINFOPAGE = 5;
	
	static void run() {

		int mount = DB.countBoard("select count(*) from register ");
		int key = 1;
		int mountPage;
		
		if(mount%MEMINFOPAGE==0) {
			mountPage = mount/MEMINFOPAGE;
		}
		else {
			mountPage = mount/MEMINFOPAGE +1;
		}
		
		Display.Line();
		Ctx.wn(Ctx.padR("ID", 10) + Ctx.padR("e-mail", 22) + "가입일자");
		Display.Line();
		DBmem.dbMeminfoList("select * from register limit " + (key-1) + "," + MEMINFOPAGE);
		Display.Line();
		Display.space(17);	
		Ctx.wn("page" + (key) + "/" + mountPage);
		Display.Line();	
		
		String cmd = "";
		
		loop_mem : while(true) {
			
			Ctx.wn("[1~" + mountPage + "]해당 페이지로 이동 [d]회원 삭제 [e]뒤로");
			cmd = Csc.readlong();

			switch (cmd) {
			case "d":
				String delId = "";
				String delyn = "";
				
				Ctx.wn("삭제할 회원 id를 입력하세요 [e]뒤로 ");
				delId = Csc.readlong();
				
				if(delId.equals("e")){
					break loop_mem;
				}
				else if(DB.countBoard("select count(*) from register where id = '"+ delId +"'")==0){
					Ctx.wn("존재하지 않는 회원입니다.");
					break loop_mem;
				}
				else {
				Ctx.wn(delId + " 회원 정보를 삭제합니까? y/n");
					delyn = Csc.readlong();
					
					if(delyn.equals("y")) {
						DB.dbExecuteUpdate("delete from register where id = '"+ delId +"'");
						Ctx.wn(delId + " 회원 정보를 삭제했습니다.");
						break loop_mem;
					}
					else{
						Ctx.wn("회원 정보를 삭제하지 않았습니다.");
						break loop_mem;
					}
				}
				//break;
			case "e":
				break loop_mem;
			default:
				key = Util.Cet.intToString(cmd);
				
				if (key > mountPage || key < 1) {
					Ctx.wn("해당 페이지가 없습니다.");
				} else {
					Display.Line();
					Ctx.wn(Ctx.padR("ID", 10) + Ctx.padR("e-mail", 22) + "가입일자");
					Display.Line();
					DBmem.dbMeminfoList("select * from register limit " + (key-1)*MEMINFOPAGE + "," + MEMINFOPAGE);
					Display.Line();
					Display.space(17);	
					Ctx.wn("page" + (key) + "/" + mountPage);
					Display.Line();
				}
				
			}
		}
		
	}
}
