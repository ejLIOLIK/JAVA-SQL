package Util;

import java.util.Random;

public class Cet {

	public static int intToString (String str) {
		try{
            int number = Integer.parseInt(str);
            return number ; 
        }
        catch (NumberFormatException ex){
        	System.out.println("잘못된 입력입니다.");
            ex.printStackTrace();
        }
		return -1;
	} 
	
	public static int random(int scale, int point) {
		int ran = (int)(Math.random()*scale + point);
		return ran;
	}
	
}
