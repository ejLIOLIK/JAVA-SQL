package Proc;

import DB.DB;
import Mysql.Display;
import Util.Csc;
import Util.Ctx;

public class ProcReadsql {

	static void run() {

		Ctx.wn("읽을 글 번호를 입력하세요. [e]뒤로");
		String num = Csc.readlong();
		boolean blrcd = true ; // 추천 여부 ( 게시글에 한 번 들어와서 여러 번 추천은 불가능 )
		boolean blrpt = true ; // 신고 여부 ( 게시글에 한 번 들어와서 여러 번 신고 불가능 )

		loop_readQuit : while (true) {			
			
			switch (num) {
			case "e":
				break loop_readQuit;
			default:
				
				Display.dpLoginId();
				Display.Line();
				
				if(DB.countBoard("select count(*) from board where num = " + num)==0) {
					Ctx.wn("해당 게시글이 존재하지 않습니다.");
					Display.Line();
					break loop_readQuit;
				}
				else {
				
				DB.dbExecuteQuery("select * from board where num = " + num);
				DB.dbExecuteUpdate("update board set hit=hit+1 where num=" + num); // 조회수 1 올려주기
				Display.Line();

				ProcReplysql.exReply(num);
				
				String key = Util.Csc.readlong();
				
				//[1]리플입력 [2]추천 [3]신고 [e]뒤로
				switch (key) {
				case "1":
					ProcReplysql.imReply(num);
					break;
				case "2":
					if(blrcd) {
					Ctx.wn("이 게시글을 추천 했습니다.");
					DB.dbExecuteUpdate("update board set recmd=recmd+1 where num=" + num); // 추천수 1 올려주기
					blrcd = false;
					}
					else {
						Ctx.wn("이미 추천했습니다.");
					}
					break;
				case "3":
					if(blrpt) {
					Ctx.wn("신고했습니다.");
					DB.dbExecuteUpdate("update board set report=report+1 where num=" + num); // 조회수 1 올려주기
					blrpt = false;
					}
					else {
						Ctx.wn("이미 신고했습니다.");
					}
					break;
				case "e":
					break loop_readQuit;
				default:					
				}
				}
			}
		}
	}
}
