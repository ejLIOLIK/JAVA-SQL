package Proc;

import DB.DB;
import Util.Csc;
import Util.Ctx;

public class ProcLogin {
	
	public static boolean blLogin = false;
	public static String idLogin = "";
	
	static void run() { // 아이디 어딘가에 저장해야... 
		
		if(blLogin) {
			blLogin = false; // 로그아웃
			idLogin = ""; // 로그인정보 삭제
		}
		else {

			String id = "";
			String pw = "";

			while (true) {

				Ctx.wn("아이디를 입력하세요. [e]뒤로");
				id = Csc.readlong();

				if (id.equals("e")) {
					break;
				}

				Ctx.wn("비밀번호를 입력하세요.");
				pw = Csc.readlong();

				if (DB.dblogin(id, pw)) {
					Ctx.wn("로그인 성공");
					idLogin = id;
					blLogin = true;
					break;
				} else {
					Ctx.wn("로그인 실패");
				}
			}
		}
	}
}
