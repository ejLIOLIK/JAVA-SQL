package Site.Board.Proc;

import Site.Board.DB.DB;
import Util.Csc;
import Util.Ctx;

public class ProcEdit {
	static void run() {

		String tmp = "";
		String num = "";

		String cmd = "";
		String query = "";

		Ctx.wn("수정할 글 번호를 입력하세요.");
		cmd = Csc.readlong();
		num = cmd;

		Ctx.wn("무엇을 수정하시겠습니까? [t]제목 [c]내용 [w]작성자");
		cmd = Csc.readlong();

		switch (cmd) {
		case "t":
			Ctx.wn("수정할 제목을 입력하세요");
			cmd = Csc.readlong();
			tmp = cmd;
			query = "update " + DB.TABLE + " set title = '" + tmp + "' where num = '" + num + "'";
			break;
		case "c":
			Ctx.wn("수정할 내용을 입력하세요");
			cmd = Csc.readlong();
			tmp = cmd;
			query = "update " + DB.TABLE + " set contents = '" + tmp + "' where num = '" + num + "'";
			break;
		case "w":
			Ctx.wn("수정할 내용을 입력하세요");
			cmd = Csc.readlong();
			tmp = cmd;
			query = "update " + DB.TABLE + " set id = '" + tmp + "' where num = '" + num + "'";
			break;
		default:
		}

		DB.dbExecuteUpdate(query);

//		DB.checkQuery(query);

	}
}
