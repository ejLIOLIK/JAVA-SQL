package Site.Board.Proc;

import Site.Board.DB.DB;
import Util.Cdp;
import Util.Csc;
import Util.Ctx;

public class ProcList {
	
	static void run() {
		
		String cmd = "";
		
		while(true) {
		
			String query = "select * from "+DB.TABLE+" order by num desc ";
			//String query = "select * from board order by num desc ";
			
			// 게시판 출력
			dpListTitle();
			DB.dbExecuteQueryList(query);
			
			//DB.checkQuery(query);
			
			Cdp.line("-", DP.DPNUM);
			Ctx.wn("[r]읽기 [q]뒤로");
			cmd = Csc.readlong();
			
			if(cmd.equals("q")) {
				break;
			}
			else if(cmd.equals("r")) {
				ProcRead.run();
			}
			else {
				Ctx.wn("잘못된 입력입니다.");
			}
		}
	}
	
	static void dpListTitle() {
		
		Cdp.line("-", DP.DPNUM);
		Ctx.wn( Ctx.padR("번호", 5) + Ctx.padR("제목", 30) + Ctx.padR("작성자", 10) + Ctx.padR("조회수", 5) + Ctx.padR("추천수", 5) + "날짜" );
		Cdp.line("-", DP.DPNUM);
	}
}
