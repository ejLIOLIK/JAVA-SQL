package Site.Board.Proc;

import Site.Board.DB.DB;
import Util.Csc;

public class ProcBoard {

	public void run() {
		
		DB.TABLE = "board" ;
		DB.REPLY_TABLE = "reply" ;
		
		DB.dbInit();

		DP.dpBoardTitle(); 
		
		String cmd = ""; // 키 입력 받음

		quit_board : while(true) {
			
			// 출력
			DP.dpBoardMenu();
			
			// 입력
			cmd = Csc.readlong();
			
			//[l]리스트 [r]읽기 [s]검색 [w]쓰기 [e]수정 [d]삭제 [q]뒤로
			//[o]로그인 [p]회원가입 //[o]로그아웃
			switch (cmd) {
			case "l":
				ProcList.run();
				break;
			case "r":
				ProcRead.run();
				break;
			case "w":
				ProcWrite.run();
				break;
			case "e":
				ProcEdit.run();
				break;
			case "d":
				ProcDelete.run();
				break;
			case "q":
				break quit_board;
			default:
			}
			
		}
		
		
	}
}
