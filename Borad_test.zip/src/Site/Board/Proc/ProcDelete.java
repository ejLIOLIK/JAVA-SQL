package Site.Board.Proc;

import Site.Board.DB.DB;
import Util.Csc;
import Util.Ctx;

public class ProcDelete {
	static void run() {

		String cmd = "";
		String query = "";

		Ctx.wn("삭제할 글 번호를 입력하세요. [q]뒤로");

		cmd = Csc.readlong();

		if (!cmd.equals("q")) {
			query = "delete from " + DB.TABLE + " where num = " + cmd + " ";

			DB.dbExecuteUpdate(query);
//			DB.checkQuery(query);

			Ctx.wn(cmd + " 번 글이 삭제되었습니다.");
		}
	}
}
