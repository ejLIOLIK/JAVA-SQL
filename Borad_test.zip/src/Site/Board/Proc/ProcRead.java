package Site.Board.Proc;

import Site.Board.DB.DB;
import Util.Cdp;
import Util.Csc;
import Util.Ctx;

public class ProcRead {

	static void run() {

		String cmd = "";
		String postNum = "";
		String query = "";

		Ctx.wn("읽을 글 번호를 입력하세요. [q]뒤로");

		cmd = Csc.readlong();
		postNum = cmd;

		if (!cmd.equals("q")) {

			query = "select * from " + DB.TABLE + " where num = " + postNum + " ";

			loop_read: while (true) {

				Cdp.line("-", DP.DPNUM);
				DB.dbExecuteQueryRead(query);

//				DB.checkQuery(query);

				Cdp.line("-", DP.DPNUM);
				Cdp.space(18);
				Ctx.wn("[q] 나가기 ");

				cmd = Csc.readlong();

				switch (cmd) {
				case "q":
					break loop_read;
				default:
					Ctx.wn("잘못된 입력입니다.");
				}
			}
		}
	}
}
