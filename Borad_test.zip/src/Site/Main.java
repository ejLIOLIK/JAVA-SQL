package Site;

import Site.Board.Proc.ProcBoard;

public class Main {
	public static void main(String[] args) {
		
		ProcBoard site = new ProcBoard();
		site.run();
	}
}