package Site.Board.List;

public class ListReport {

}
