package Site.Board.Proc;

import Site.DP;
import Site.Board.DB.DB;
import Site.Proc.ProcLogin;
import Util.Cdp;
import Util.Cet;
import Util.Csc;
import Util.Ctx;

public class ProcList {
	
	static void run(int REPORTNUM, int PAGENUM) {
		
		int mountPage = 0; 											//총 페이지 수
		int curPage = 1;										//현재 페이지. 시작값 1.

		int mountPost = DB.dbCountQuery("select count(*) from "+DB.TABLE+" where report < "+ REPORTNUM); //총 게시글 수.
		String cmd = "";
		
		if(mountPost%PAGENUM==0) {
			mountPage = mountPost / PAGENUM;
		}
		else {
			mountPage = mountPost / PAGENUM + 1;
		}
		
		while(true) {
		
			String query = "select * from "+DB.TABLE+" where report<3 order by num desc limit " + (curPage - 1)*PAGENUM + "," + PAGENUM + " ";
			
			// 게시판 출력
			dpListTitle();
			DB.dbExecuteQueryList(query);
			dpListFin(curPage, mountPage);
			
//			DB.checkQuery(query);
		
			
			Ctx.wn("이동하고자 하는 페이지 번호를 입력하세요. [r]읽기 [q]뒤로");
			cmd = Csc.readlong();
			
			if(cmd.equals("q")) {
				curPage = 1;
				break;
			}
			else if(cmd.equals("r")) {
				ProcRead.run();
				curPage = 1; // 첫 페이지로
			}
			else {
				curPage = Cet.intToString(cmd);
				
				if(curPage > mountPage || curPage < 1) {
					Ctx.wn("존재하지 않는 페이지입니다.");
					break;
				}
			}
		}
	}
	
	static void dpListTitle() {
		
		if(ProcLogin.blLogin) {
			Ctx.wn("ID : " + ProcLogin.idLogin);
		}
		else {
			Ctx.wn("로그인 해주세요.");
		}
		
		Cdp.line("-", DP.DPNUM);
		Ctx.wn( Ctx.padR("번호", 5) + Ctx.padR("제목", 30) + Ctx.padR("작성자", 10) + Ctx.padR("조회수", 5) + Ctx.padR("추천수", 5) + "날짜" );
		Cdp.line("-", DP.DPNUM);
		DB.dbExecuteQueryList("select * from "+ DB.TABLE +" where report<3 order by recmd desc limit 0,3"); // 추천글 페이지 출력
		Cdp.line("-", DP.DPNUM);
	}

	static void dpListFin(int curPage, int mountPage) {
		Cdp.line("-", DP.DPNUM);
		Cdp.space(38);	Ctx.wn("현재 페이지 ["+ curPage +"/"+ mountPage +"]");
		Cdp.line("-", DP.DPNUM);
	}
}
