package Site.Board.Proc;

import Site.DP;
import Site.Board.DB.DB;
import Util.Csc;

public class ProcBoard {
	
	public String boardServer="";
	public String repServer="";
	public int REPORTNUM;
	final public int PAGENUM = 7; // 페이지당 출력 수
	
	public ProcBoard(int REPORTNUM) {
		// 신고 수 일정 수량 이상이면 출력 안하기 위해서
		// 일정 수량 지정받는 생성자
		this.REPORTNUM = REPORTNUM;
	}
	
	public void setBoardTable(String boardServer, String repServer)
	{	// 테이블 지정해주는 메소드
		this.boardServer = boardServer;
		this.repServer = repServer;
	}

	public void run() {
		
		DB.TABLE = boardServer ;
		DB.REPLY_TABLE = repServer ;

		DP.dpBoardTitle(); 
		
		String cmd = ""; // 키 입력 받음

		quit_board : while(true) {
			
			// 출력
			DP.dpBoardMenu();
			
			// 입력
			cmd = Csc.readlong();
			
			//[l]리스트 [r]읽기 [s]검색 [w]쓰기 [e]수정 [d]삭제 [q]뒤로
			//[o]로그인 [p]회원가입 //[o]로그아웃
			
			switch (cmd) {
			case "l":
				ProcList.run(REPORTNUM, PAGENUM);
				break;
			case "r":
				ProcRead.run();
				break;
			case "s":
				ProcSearch.run(REPORTNUM, PAGENUM);
				break;
			case "w":
				ProcWrite.run();
				break;
			case "e":
				ProcEdit.run();
			case "d":
				ProcDelete.run();
			case "q":
				break quit_board;
			default:
			}
			
		}
		
		
	}
}
