package Site.Proc;

import Site.Board.DB.DB;
import Util.Csc;
import Util.Ctx;

public class ProcRegist {

	public static void run() {

		String cmd="";
		
		String email="";
		String id="";
		String pw="";
		
		String countQ;
		
		Ctx.wn("이메일을 입력하세요.");
		cmd = Csc.readlong();
		email = cmd;
		
		while(true) {
			Ctx.wn("아이디를 입력하세요.");
			cmd = Csc.readlong();
			id = cmd;
			countQ = "select count(*) from " + DB.MEM_TABLE + " where id = '" + id + "'";
			
			if(id.equals("손님") || id.equals("q"))
			{
				Ctx.wn("사용할 수 없는 아이디입니다.");
				
			}
			else if(DB.dbCountQuery(countQ)>0) //dbCountQuery(String query) 해서 >0 이면 존재하는 아이디
			{
				Ctx.wn("이미 존재하는 아이디입니다.");
//				DB.checkQuery(countQ);
			}
			else {
				break;
			}
		}
		
		while(true) {
			Ctx.wn("비밀번호를 입력하세요.");
			cmd = Csc.readlong();
			pw = cmd;

			Ctx.wn("비밀번호를 다시 입력하세요.");
			cmd = Csc.readlong();

			if (pw.equals(cmd)) {
				Ctx.wn("등록되었습니다.");
				break;
			} else {
				Ctx.wn("일치하지 않습니다.");
			}
		}
		
		DB.dbExecuteUpdate("insert into register (email, id, pw) values ('"+ email +"', '"+ id +"', '"+ pw +"')");
//		DB.checkQuery("insert into register (email, id, pw) values ('"+ email +"', '"+ id +"', '"+ pw +"')");
		Ctx.wn("등록이 완료되었습니다. 로그인 창으로 이동합니다.");
		
		 ProcLogin.run();

	}
}
