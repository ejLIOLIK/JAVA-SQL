package Site;

import Site.Gate.Gate;
import Site.Gate.GateAdmin;
import Site.Gate.GateLogin;
import Site.Proc.ProcLogin;

public class Main {
	public static void main(String[] args) {
		
		boolean blSite = true; 

		Gate gateAdmin = new GateAdmin();
		Gate gateLogin = new GateLogin();
		Gate gate = new Gate();
		
		while(blSite) {
		
			if (ProcLogin.blLogin && ProcLogin.idLogin.equals("admin")) {
				gateAdmin.run();
				blSite = gateAdmin.Menu();
			} else if (ProcLogin.blLogin) {
				gateLogin.run();
				blSite = gateLogin.Menu();
			} else {
				gate.run();
				blSite = gate.Menu();
			}
		}
	}
}