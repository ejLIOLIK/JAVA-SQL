package Site.Gate;

import Site.DP;
import Site.Board.DB.DB;
import Util.Cdp;
import Util.Csc;
import Util.Ctx;

public class ProcReport {
	
	int REPORTNUM;
	int ADMINPAGE;
	
	public ProcReport(int ADMINPAGE, int REPORTNUM) {
		
		this.ADMINPAGE = ADMINPAGE;
		this.REPORTNUM = REPORTNUM;
	}
	
	public void run() {
		
		int mountPage = 0;	
		int curPage = 1;	

		String cmd = "";	
		String num = "";

		loop_a : while(true) {
			
			Ctx.wn("게시판을 선택하세요. [b]자유게시판 [m]장터게시판");
			cmd = Csc.readlong();

			switch(cmd) {
			case "b":
				DB.TABLE = "board";
			break loop_a;
			case "m":
				DB.TABLE = "board_market";
			break loop_a;
			default:
				Ctx.wn("잘못된 입력입니다.");
			}
		}
		
		int mountPost = DB.dbCountQuery("select count(*) from "+ DB.TABLE +" where report >= " + REPORTNUM);
		
		if(mountPost%ADMINPAGE==0) {
			mountPage = mountPost / ADMINPAGE;
		}
		else {
			mountPage = mountPost / ADMINPAGE + 1;
		}

		loop_b : while(true) {
		
			String query = "select * from "+ DB.TABLE +" where report >= " + REPORTNUM + " order by num desc limit "+ (curPage-1)*ADMINPAGE +","+ ADMINPAGE;
	
			//출력
			
			dpReportTitle();
			DB.dbExecuteQueryListAdmin(query); //신고글 출력
			dpReportFin(curPage, mountPage);
			
			Ctx.wn("이동하고자 하는 페이지 번호를 입력하세요. [d] 삭제 [r] 복구 [q] 뒤로");
			cmd = Csc.readlong();
			
			switch(cmd) {
			case "q" :
				break loop_b;
			case "d" :
				Ctx.wn("삭제할 게시글 번호를 입력하세요.");
				num = Csc.readlong();
				DB.dbExecuteUpdate("delete from "+ DB.TABLE +" where num=" + num); // 
				Ctx.wn(num + "번 게시글 삭제.");
				break;
			case "r" :
				Ctx.wn("복구할 게시글 번호를 입력하세요.");
				num = Csc.readlong();
				DB.dbExecuteUpdate("update "+ DB.TABLE +" set report = 0 where num=" + num); // 
				Ctx.wn(num + "번 게시글 복구.");
				break;
				
				default:
					curPage = Util.Cet.intToString(cmd);
					if (curPage > mountPage || curPage < 1) {
						Ctx.wn("해당 페이지가 없습니다.");
					}
			}
		}
	}
	
	void dpReportTitle() {
		Cdp.line("-", DP.DPNUM);
		Ctx.wn(Ctx.padR("글번호", 5) + Ctx.padR("제목", 28) + Ctx.padR("ID", 7)  + Ctx.padR("조회수", 4) + Ctx.padR("추천수", 4)
				+ Ctx.padR("신고수", 7) + "날짜");
		Cdp.line("-", DP.DPNUM);
	}

	void dpReportFin(int curPage, int mountPage) {
		Cdp.line("-", DP.DPNUM);
		Cdp.space(53);
		Ctx.wn("page" + curPage + "/" + mountPage);
		Cdp.line("-", DP.DPNUM);
	}
}
