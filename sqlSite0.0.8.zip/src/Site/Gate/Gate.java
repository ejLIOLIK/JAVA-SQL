package Site.Gate;

import Site.DP;
import Site.Board.DB.DB;
import Site.Proc.ProcLogin;
import Site.Proc.ProcRegist;
import Util.Cdp;
import Util.Csc;
import Util.Ctx;

public class Gate {
	
	final public int REPORTNUM = 3;

	public void run() {
		
		DB.dbInit();
		DP.dpSiteTitle();

	}
	
	public void dpSiteMenu(){
		
		String dot = "=";
		
		//[b]자유게시판 [m]장터게시판 [o]로그아웃
		
		Ctx.wn("현재 손님입니다. 로그인 해주세요");
		
		Cdp.line(dot, DP.DPNUM);

		Cdp.space(41);
		Ctx.wn("[o]로그인 [p]회원가입 [q]종료");
		
		Cdp.line(dot, DP.DPNUM);
	}
	
	public boolean Menu() {
		
		String cmd = "";

		while (true) {

			this.dpSiteMenu();

			// [b]자유게시판 [m]장터게시판 [o]로그아웃 [q]종료

			cmd = Csc.readlong();

			switch (cmd) {
			case "o":
				ProcLogin.run();
				return true;
			case "p":
				ProcRegist.run();
				return true;
			case "q":
				Ctx.wn("종료합니다.");
				return false;
			default:
			}
		}
	}
}
