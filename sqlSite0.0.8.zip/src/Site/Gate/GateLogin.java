package Site.Gate;

import Site.DP;
import Site.Board.Proc.ProcBoard;
import Site.Proc.ProcLogin;
import Util.Cdp;
import Util.Csc;
import Util.Ctx;

public class GateLogin extends Gate {

	@Override
	public void dpSiteMenu(){
		
		String dot = "=";

		// [b]자유게시판 [m]장터게시판 [o]로그아웃

		Ctx.wn("ID : " + ProcLogin.idLogin);

		Cdp.line(dot, DP.DPNUM);

		Cdp.space(28);
		Ctx.wn("[b]자유게시판 [m]장터게시판 [o]로그아웃 [q]종료");

		Cdp.line(dot, DP.DPNUM);
	}
	
	@Override
	public boolean Menu() {
		
		ProcBoard procBoard = new ProcBoard(this.REPORTNUM);
		String cmd = "";

		while (true) {

			this.dpSiteMenu();
			
			// [b]자유게시판 [m]장터게시판 [o]로그아웃 [q]종료

			cmd = Csc.readlong();

			if(ProcLogin.blLogin)//로그인 시
			{
				switch (cmd) {
				case "b":
					procBoard.setBoardTable("board", "reply");
					procBoard.run();
					return true;
				case "m":
					procBoard.setBoardTable("board_market", "reply_market");
					procBoard.run();
					return true;
				case "o":
					ProcLogin.logout();
					return true;
				case "q":
					Ctx.wn("종료합니다.");
					return false;
				default:
				}
			}
		}
	}
}
