package Site.Gate;

import java.sql.SQLException;

import Site.DP;
import Site.Board.DB.DB;
import Util.Cdp;
import Util.Csc;
import Util.Ctx;

public class ProcMeminfo {
	
	int ADMINPAGE;
	
	public ProcMeminfo(int ADMINPAGE) {
		
		this.ADMINPAGE = ADMINPAGE;
		
	}

	public void run() {

		int curPage = 1;
		int mountPage;

		int mount = DB.dbCountQuery("select count(*) from "+ DB.MEM_TABLE +" ");
		
		if(mount%ADMINPAGE==0) {
			mountPage = mount/ADMINPAGE;
		}
		else {
			mountPage = mount/ADMINPAGE +1;
		}
		
		String cmd = "";
		
		loop_mem : while(true) {
			
			dpMemTitle();
			dbMeminfoList("select * from "+ DB.MEM_TABLE +" limit " + (curPage-1)*ADMINPAGE + "," + ADMINPAGE);
			dpMemFin(curPage, mountPage);
			
			Ctx.wn("이동하고자 하는 페이지 번호를 입력하세요. [d]회원 삭제 [q]뒤로");
			cmd = Csc.readlong();

			switch (cmd) {
			case "d":
				String delId = "";
				String delyn = "";
				
				Ctx.wn("삭제할 회원 id를 입력하세요 [q]뒤로 ");
				delId = Csc.readlong();
				
				if(delId.equals("q")){
					break loop_mem;
				}
				else if(DB.dbCountQuery("select count(*) from register where id = '"+ delId +"'")==0){
					Ctx.wn("존재하지 않는 회원입니다.");
					break loop_mem;
				}
				else {
				Ctx.wn(delId + " 회원 정보를 삭제합니까? y/n");
					delyn = Csc.readlong();
					
					if(delyn.equals("y")) {
						DB.dbExecuteUpdate("delete from register where id = '"+ delId +"'");
						Ctx.wn(delId + " 회원 정보를 삭제했습니다.");
						break loop_mem;
					}
					else{
						Ctx.wn("회원 정보를 삭제하지 않았습니다.");
						break loop_mem;
					}
				}
				//break;
			case "q":
				break loop_mem;
			default:
				curPage = Util.Cet.intToString(cmd);
				
				if (curPage > mountPage || curPage < 1) {
					Ctx.wn("해당 페이지가 없습니다.");
				} 				
			}
		}
	}
	
	public void dpMemTitle() {
		Cdp.line("-", DP.DPNUM);
		Ctx.wn(Ctx.padR("ID", 10) + Ctx.padR("e-mail", 22) + "가입일자");
		Cdp.line("-", DP.DPNUM);
	}
	
	public void dpMemFin(int curPage, int mountPage) {
		Cdp.line("-", DP.DPNUM);
		Cdp.space(17);	
		Ctx.wn("page" + curPage + "/" + mountPage);
		Cdp.line("-", DP.DPNUM);
	}
	
	public void dbMeminfoList(String query) {
		
		try {
			DB.result = DB.st.executeQuery(query);
			while (DB.result.next()) {	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				
				Ctx.w(Ctx.padR(DB.result.getString("id"),8));	// p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				Ctx.w(Ctx.padR(DB.result.getString("email"),20));	
				Ctx.wn(DB.result.getString("regiday"));	
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
}
