package Proc;

import DB.DB;
import Mysql.Display;
import Util.Csc;
import Util.Ctx;

public class ProcReplysql {
	
	static void exReply(String num) {
		
		Display.showReplyTitle();				
		if(DB.countBoard("select count(*) from reply where replyNum =" + num) == 0){
			Ctx.wn(" 작성된 리플이 없습니다.");
		}
		else {
			DB.dbexecuteQueryReply("select * from reply where replyNum = " + num);
		}

		// 리플 선택지
		// [1]리플입력 [2]추천 [3]신고 [e]뒤로
		Display.showReplyMenu();
	}
	
	static void imReply(String num) {
		
		String replyCon = "";
		Ctx.wn("리플을 입력해주세요:");
		replyCon = Csc.readlong();

		Ctx.wn("ID를 입력하세요");
		String ID = Csc.readlong();
		
		// 덧글 입력 
		DB.dbExecuteUpdate("insert reply set replyNum = '" + num + "', replyText = '" + replyCon
				+ "', replyId = '" + ID + "';");
		// 해당 게시글 덧글 수 +1
		DB.dbExecuteUpdate("update board set replyCount = replyCount+1 where num = '" + num + "';");
		
	}
}
