package Proc;

import Admin.admin;
import DB.DB;
import Mysql.Display;
import Util.Csc;
import Util.Ctx;

public class ProcBoard {

	public void run() {
		
		Display.showTitle();
		DB.dbInit();
		
		loop_quit : while(true) {
		
			String key = "";
			
			Display.showMainMenu();
			key = Csc.readlong();

			// [1]글리스트 [2]글읽기 [3]글쓰기 [4]글삭제 [5]글수정 [6]검색 [e]종료
			switch (key) {
			case "1":
				ProcListsql.run();
				break;
			case "2":
				ProcReadsql.run();
				break;
			case "3":
				ProcWritesql.run();
				break;
			case "4":
				ProcDeletesql.run();
				break;
			case "5":
				ProcEditsql.run();
				break;
			case "6":
				ProcSearchsql.run();
				break;
			case "e":
				Ctx.wn("종료됩니다.");
				break loop_quit;
			case "admin":
				Ctx.wn("password : ");
				key = Csc.readlong();
				if(key.equals("1111")) { // 비밀번호
					Ctx.wn("관리자 모드 성공");
					admin.run();
				}
				else {
					Ctx.wn("관리자 모드 실패");
				}
				break;
			default:
			}
		
		}
	}
}
