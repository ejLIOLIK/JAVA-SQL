package Util;

public class Cdp {

	public static void line(String s, int n) {
		for(int i=0;i<n;i++) {
			Ctx.w(s);
		}
		Ctx.wn("");
	}
	
	public static void space(int c) {
		for(int i=0;i<c;i++) {
			Ctx.w(" ");
		}
	}
	
	public static String strDrop(String s, int n) {
		
		String tmp;
		
		if(s.length()>n) {
			tmp = s.substring(0,n-1);
			tmp = tmp + "...";
		}
		else {
			tmp = s;
		}
		
		return tmp;
	}	
}
