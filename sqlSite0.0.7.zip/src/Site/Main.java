package Site;

public class Main {
	public static void main(String[] args) {
		
		Site site = new Site();
		site.run();
	}
}