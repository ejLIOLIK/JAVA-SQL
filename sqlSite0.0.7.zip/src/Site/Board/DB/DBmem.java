package Site.Board.DB;

import java.sql.SQLException;

import Util.Ctx;

public class DBmem {

	public static void dbMeminfoList(String query) {
		
		try {
			DB.result = DB.st.executeQuery(query);
			while (DB.result.next()) {	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				
				Ctx.w(Ctx.padR(DB.result.getString("id"),8));	// p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				Ctx.w(Ctx.padR(DB.result.getString("email"),20));	
				Ctx.wn(DB.result.getString("regiday"));	
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
}
