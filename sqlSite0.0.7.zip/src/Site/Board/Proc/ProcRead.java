package Site.Board.Proc;

import Site.Board.DB.DB;
import Util.Cdp;
import Util.Csc;
import Util.Ctx;

public class ProcRead {

	static void run() {

		String cmd = "";
		String postNum = "";
		String query = "";
		
		boolean blrecmd = false ;
		boolean blreport = false ;

		Ctx.wn("읽을 글 번호를 입력하세요. [q]뒤로");

		cmd = Csc.readlong();
		postNum = cmd;

		if (!cmd.equals("q")) {
			
			query = "select * from " + DB.TABLE + " where num = " + postNum + " ";

			loop_read : while (true) {

				Cdp.line("-", DP.DPNUM);
				DB.dbExecuteQueryRead(query);
								
//				DB.checkQuery(query);

				ProcReply.exReply(postNum);
				
				if (DB.dbCheckRight(postNum)) {
					Cdp.space(12);
					Ctx.wn("[r] 리플추가 [w] 추천 [e] 삭제 [q] 나가기 ");
				} else {
					Cdp.space(12);
					Ctx.wn("[r] 리플추가 [w] 추천 [e] 신고 [q] 나가기 ");
				}

				cmd = Csc.readlong();
				
				switch(cmd) {
				case "r":
					ProcReply.imReply(postNum);
					break;
				case "w":
					if(!blrecmd) {
						DB.dbExecuteUpdate("update " + DB.TABLE + " set recmd = recmd + 1 where num = " + postNum);
						blrecmd = true;
						Ctx.wn("추천했습니다.");
					}
					else {
						Ctx.wn("이미 추천했습니다.");
					}
					break;
				case "e":
					if(DB.dbCheckRight(postNum)) {
						DB.dbExecuteUpdate("update "+ DB.TABLE +" set report = report + 3 where num = "+ postNum);
						blreport = true;
						Ctx.wn("삭제했습니다.");
						break loop_read;
					}
					else if(!blreport) {
						DB.dbExecuteUpdate("update "+ DB.TABLE +" set report = report + 1 where num = "+ postNum);
						blreport = true;
						Ctx.wn("신고했습니다.");
					}
					else {
						Ctx.wn("이미 신고했습니다.");
					}
					break;
				case "q":
					DB.dbExecuteUpdate("update "+ DB.TABLE +" set hit = hit + 1 where num = "+ postNum); // 리플 입력시에는 조회수 오르지 않도록 메소드 끝날 때 조회수 올려줌.
					break loop_read;
					default :
						Ctx.wn("잘못된 입력입니다.");
				}
			}
		}
	}
}
