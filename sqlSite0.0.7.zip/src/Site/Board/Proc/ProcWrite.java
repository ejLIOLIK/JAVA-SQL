package Site.Board.Proc;

import Site.Board.DB.DB;
import Site.Proc.ProcLogin;
import Util.Cdp;
import Util.Csc;
import Util.Ctx;

public class ProcWrite {
	static void run() {
		
		String title = "";
		String contents = "";
		String id = "";
		
		String query = "";
		
		Ctx.wn("글 제목을 입력하세요");
		title = Csc.readlong();
		
		Ctx.wn("글 내용을 입력하세요");
		contents = Csc.readlong();
		
		id = ProcLogin.idLogin;
		
		query = "insert into "+DB.TABLE+" (id, title, contents, hit, replyCount, recmd, report) values ('"+id+"', '"+title+"', '"+contents+"', 0, 0, 0, 0) " ;
		
		DB.dbExecuteUpdate(query);
//		DB.checkQuery(query);
		
	}
}
