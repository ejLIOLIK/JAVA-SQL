package Site.Board.Proc;

import Site.DP;
import Site.Board.DB.DB;
import Site.Proc.ProcLogin;
import Util.Csc;
import Util.Ctx;

public class ProcBoard {

	public void run(String boardServer, String repServer) {
		
		DB.TABLE = boardServer ;
		DB.REPLY_TABLE = repServer ;

		DP.dpBoardTitle(); 
		
		String cmd = ""; // 키 입력 받음

		quit_board : while(true) {
			
			// 출력
			DP.dpBoardMenu();
			
			// 입력
			cmd = Csc.readlong();
			
			//[l]리스트 [r]읽기 [s]검색 [w]쓰기 [e]수정 [d]삭제 [q]뒤로
			//[o]로그인 [p]회원가입 //[o]로그아웃
			switch (cmd) {
			case "l":
				ProcList.run();
				break;
			case "r":
				ProcRead.run();
				break;
			case "s":
				ProcSearch.run();
				break;
			case "w":
				if(ProcLogin.blLogin) {
					ProcWrite.run();}
				else {
					Ctx.wn("로그인 후 이용가능합니다.");}
				break;
			case "e":
				if(ProcLogin.blLogin) {
				ProcEdit.run();}
				else {
					Ctx.wn("로그인 후 이용가능합니다.");}
				break;
			case "d":
				if(ProcLogin.blLogin) {
				ProcDelete.run();}
				else {
					Ctx.wn("로그인 후 이용가능합니다.");}
				break;
			case "q":
				break quit_board;
			default:
			}
			
		}
		
		
	}
}
