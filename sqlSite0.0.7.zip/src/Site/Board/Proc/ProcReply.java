package Site.Board.Proc;

import Site.Board.DB.DB;
import Site.Proc.ProcLogin;
import Util.Cdp;
import Util.Csc;
import Util.Ctx;

public class ProcReply {

	static void exReply(String postNum) {
		// 리플 출력

		String query = "select * from " + DB.REPLY_TABLE + " where replyNum = " + postNum;
		String countQ = "select count(*) from " + DB.REPLY_TABLE + " where replyNum = " + postNum;
		DB.checkQuery(query);
		
		dpReplyTitle();
		DB.dbExecuteQueryReply(query);
		
		if(DB.dbCountQuery(countQ)==0) {
			Ctx.wn(" 등록된 리플이 없습니다. ");
		}
		
		Cdp.line("-", DP.DPNUM);
	}

	static void imReply(String postNum) {
		
		String contents = "";
		String id = "";

		Ctx.wn("리플 내용을 입력하세요");
		contents = Csc.readlong();
		
		if(ProcLogin.blLogin) {
			id = ProcLogin.idLogin;
		}
		else {
			Ctx.wn("작성자를 입력하세요");
			id = Csc.readlong();
		}
		
		String query = "insert into "+ DB.REPLY_TABLE +" (replyNum, replyID, replyText) values ("+ postNum +",'"+ id +"','"+ contents +"')";
		DB.dbExecuteUpdate(query);
		DB.dbExecuteUpdate("update "+ DB.TABLE +" set replyCount = replyCount + 1 where num = "+ postNum);
		
		//DB.checkQuery(query);
		

	}

	static void dpReplyTitle() {
		Cdp.line("-", DP.DPNUM);
		Ctx.wn(Ctx.padR("Relpy ID", 12) + Ctx.padR("내용", 30));
		Cdp.line("-", DP.DPNUM);
	}
}
