package Site.admin;

import Site.DP;
import Util.Cdp;
import Util.Csc;
import Util.Ctx;

public class Admin {
	public static void run() {
		String cmd = "";

		loop_adminQuit: while (true) {
			Cdp.line("-", DP.DPNUM);
			Ctx.wn(" [1]신고 게시글 관리 [2]회원 정보 관리 [q]나가기 ");
			Cdp.line("-", DP.DPNUM);
			cmd = Csc.readlong();
			switch (cmd) {
			case "1":
				ProcReport.run();
				break;
				case "2":
				ProcMeminfo.run();
				break;
			case "q":
				break loop_adminQuit;
			default:
			}
		}
	}
}
