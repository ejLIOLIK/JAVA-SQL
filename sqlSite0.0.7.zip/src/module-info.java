/**
 * 
 */
/**
 * @author GDJ59
 *
 */
module JavaMysqlTest {
	requires java.sql;
}