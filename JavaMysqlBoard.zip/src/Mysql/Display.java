package Mysql;

import Util.Ctx;

public class Display {
	
	final static int DPNUM = 60;
	
	static private String TITLE = "게시판 v0.0.1"; 
	
	static public void showTitle() {
		dotT();
		space(25);
		System.out.println(TITLE);
		dotT();
	}
	
	static private String MAIN_MENU = "[1]글리스트 [2]글읽기 [3]글쓰기 [4]글삭제 [5]글수정 [6]검색 [e]종료";
	static private String REPLY_MENU = "[r]리플입력 [e]뒤로";
	
	public static void Line() {
		for(int i=0;i<DPNUM;i++) {
			Ctx.w("-");
		}
		Ctx.wn("");
	}
	
	public static void dotT() {
		for(int i=0;i<DPNUM;i++) {
			Ctx.w("=");
		}
		Ctx.wn("");
	}
	
	public static void space(int c) {
		for(int i=0;i<c;i++) {
			Ctx.w(" ");
		}
	}
	
	static public void showMainMenu() {
		Line();
		space(2);
		Ctx.wn(MAIN_MENU);
		Line();	
	}
	
	static public void showReplyMenu() {
		Line();
		space(14);
		Ctx.wn(REPLY_MENU);
		Line();	
	}
	
	static public void showListTitle () { 
		Ctx.wn(Ctx.padR("글번호", 7) + Ctx.padR("ID", 12) + Ctx.padR("제목", 29) + "조회수");
	}
	static public void showReplyTitle () {
		Ctx.wn(" ID" + Ctx.padL("Reply", 15));
	}
}
